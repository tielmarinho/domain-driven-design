
package com.example.clinica.config;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Infraestrutura (DDD). Expõe conexões ao Oracle.
 * Lê application.properties, mas permite sobrescrever por variáveis de ambiente:
 *  ORACLE_URL, ORACLE_USER, ORACLE_PASSWORD
 */
public class OracleConnectionFactory {

    private static final Properties PROPS = new Properties();

    static {
        try (InputStream in = OracleConnectionFactory.class
                .getClassLoader()
                .getResourceAsStream("application.properties")) {
            if (in != null) {
                PROPS.load(in);
            }
        } catch (IOException e) {
            throw new RuntimeException("Falha lendo application.properties", e);
        }
    }

    private static String propOrEnv(String propKey, String envKey) {
        String env = System.getenv(envKey);
        if (env != null && !env.isBlank()) return env;
        return PROPS.getProperty(propKey);
    }

    public static Connection getConnection() throws SQLException {
        String url  = propOrEnv("oracle.url", "ORACLE_URL");
        String user = propOrEnv("oracle.user", "ORACLE_USER");
        String pass = propOrEnv("oracle.password", "ORACLE_PASSWORD");
        return DriverManager.getConnection(url, user, pass);
    }
}
