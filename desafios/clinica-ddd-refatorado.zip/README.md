# Clínica – Agenda de Consultas (DDD – DAO + Service + Console/Swing)

**Pontos-chave:**
- Domínio: `domain/` (Entidades `Paciente`, `Medico`, `Consulta`).
- Portas de saída (DDD): `dao/` + `dao.jdbc/` (implementações Oracle via JDBC).
- Serviços de aplicação: `service/` (casos de uso – agendar, alterar, excluir, listar).
- Interfaces de usuário: `ui.console/` e `ui.swing/` (listar/alterar/excluir/agendar).
- Infraestrutura: `config/OracleConnectionFactory.java` (lê `application.properties` com override por env).

## Requisitos
- Java 17+
- Maven 3.8+
- Banco: **Oracle** (mantido conforme solicitado)

## Configuração de conexão
Edite `src/main/resources/application.properties` **ou** use variáveis de ambiente:
```bash
export ORACLE_URL="jdbc:oracle:thin:@//localhost:1521/FREEPDB1"
export ORACLE_USER="system"
export ORACLE_PASSWORD="oracle"
```

## Scripts Oracle
Em `scripts/oracle/` há:
- `01_schema.sql` com criação de tabelas e exemplos.
- `02_drop.sql` para limpeza.

## Executar (Swing – padrão)
```bash
mvn -q -DskipTests package
java -cp target/clinica-agenda-ddd-1.1.0.jar:$(mvn -q -Dexec.classpathScope=runtime -Dexec.executable=echo --non-recursive exec:classpath) com.example.clinica.App
```

## Executar (Console)
```bash
mvn -q -DskipTests package
java -Dmode=console -cp target/clinica-agenda-ddd-1.1.0.jar:$(mvn -q -Dexec.classpathScope=runtime -Dexec.executable=echo --non-recursive exec:classpath) com.example.clinica.App
```

> No Windows, substitua `:` por `;` no classpath.

## Telas / Funcionalidades
- **Console:** menu com `Listar`, `Agendar`, `Alterar`, `Excluir`.
- **Swing:** abas `Listar` (tabela + atualizar), `Alterar` (formulário), `Excluir` (ID).  
  Datas devem ser informadas no formato `yyyy-MM-dd HH:mm`.

## Observações de DDD
- Entidades puras no domínio (sem dependência de infraestrutura).
- DAOs representam **portas de saída** (persistência) e são injetados nos **Serviços** (casos de uso).
- UI não conhece JDBC – fala com `service`.

Bom proveito! — Prof. Salatiel Marinho
